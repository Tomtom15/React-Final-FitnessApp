export const TEST = "TEST"
export const USER_PROFILE="USER_PROFILE"
export const INSTRUCTOR="INSTRUCTOR"