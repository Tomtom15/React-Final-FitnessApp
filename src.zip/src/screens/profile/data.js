export default [
    {
       label:"Rice",
       value:"Rice",
       calories:"300",
       quantity:"100 gms",
       avatar:"https://www.simplyrecipes.com/wp-content/uploads/2020/02/HTC-White-Rice-Lead-4.jpg",
    },
    {
      label:"Dal",
      value:"Dal",
      calories:"100",
      quantity:"100 ml",
      avatar:"https://i2.wp.com/www.vegrecipesofindia.com/wp-content/uploads/2009/08/dhaba-style-dal-fry-recipe-1.jpg",
   },
   {
      label:"Apple",
      value:"Apple",
      calories:"50",
      quantity:"1",
      avatar:"https://cdn4.vectorstock.com/i/1000x1000/77/33/set-of-red-and-green-apple-fruits-with-cut-and-vector-1637733.jpg",
   },
   {
      label:"Cereals",
      value:"Cereals",
      calories:"120",
      quantity:"100 gms",
      avatar:"https://www.nestle-cereals.com/global/sites/g/files/qirczx356/f/styles/scale_992/public/stage_visual/images_16_0.jpg?itok=xCGZ109R",
   },
   {
      label:"Wheat",
      value:"Wheat",
      calories:"250",
      quantity:"250 gms",
      avatar:"https://5.imimg.com/data5/MV/GQ/MY-24743413/whole-wheat-grain-500x500.jpg",
   }
]