export default {
    primary:'#65A4CA',
    white:'#ffffff',
    gray:'#d3d3d3',
    red:"#ff0033",
    black:"#00000d",
    light_primary:"#ADD8E6"
}

